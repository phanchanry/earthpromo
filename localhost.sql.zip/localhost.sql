-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 21, 2015 at 04:51 PM
-- Server version: 5.5.42-37.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `earthpr3_earthpromo`
--
CREATE DATABASE `earthpr3_earthpromo` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `earthpr3_earthpromo`;

-- --------------------------------------------------------

--
-- Table structure for table `ep_category`
--

DROP TABLE IF EXISTS `ep_category`;
CREATE TABLE IF NOT EXISTS `ep_category` (
  `ep_category` int(11) NOT NULL AUTO_INCREMENT,
  `ep_title` varchar(256) NOT NULL,
  PRIMARY KEY (`ep_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `ep_category`
--

INSERT INTO `ep_category` (`ep_category`, `ep_title`) VALUES
(1, 'business'),
(2, 'jobseekers'),
(3, 'entertainment/restaurant'),
(4, 'tourist attractions'),
(5, 'talent'),
(6, 'investment opportunities');

-- --------------------------------------------------------

--
-- Table structure for table `ep_city`
--

DROP TABLE IF EXISTS `ep_city`;
CREATE TABLE IF NOT EXISTS `ep_city` (
  `ep_city` int(11) NOT NULL AUTO_INCREMENT,
  `ep_city_name` varchar(64) NOT NULL,
  `ep_state` varchar(100) NOT NULL,
  PRIMARY KEY (`ep_city`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=81 ;

--
-- Dumping data for table `ep_city`
--

INSERT INTO `ep_city` (`ep_city`, `ep_city_name`, `ep_state`) VALUES
(1, 'Montgomery', 'alabama'),
(2, 'Birmingham', 'alabama'),
(3, 'Mobile', 'alabama'),
(4, 'Juneau', 'Alaska'),
(5, 'Phoenix', 'Arizona'),
(6, 'Little Rock', 'Arkansas'),
(7, 'Sacramento', 'California'),
(8, 'Los Angeles', 'California'),
(9, 'Sandiego', 'California'),
(10, 'Sanfrancisco', 'California'),
(11, 'Denver', 'Colorado'),
(12, 'Hartford', 'Connecticut'),
(13, 'Dover', 'Delaware'),
(14, 'Tallahassee', 'Florida'),
(15, 'Atlanta', 'Georgia'),
(16, 'Columbus', 'Georgia'),
(17, 'Honolulu', 'Hawaii'),
(18, 'Boise', 'Idaho'),
(19, 'Springfield', 'Illinois'),
(20, 'Indianapolis', 'Indiana'),
(21, 'Des Moines', 'Iowa'),
(22, 'Topeka', 'Kansas'),
(23, 'Frankfort', 'Kentucky'),
(24, 'Baton Rouge', 'Louisiana'),
(25, 'New Orleans', 'Louisiana'),
(26, 'Augusta', 'Maine'),
(27, 'Annapolis', 'Maryland'),
(28, 'Boston', 'Massachusetts'),
(29, 'Lansing', 'Michigan'),
(30, 'Saint Paul', 'Minnesota'),
(31, 'Jackson', 'Mississippi'),
(32, 'Biloxi ', 'Mississippi'),
(33, 'Helena', 'Montana'),
(34, 'Lincoln', 'Nebraska'),
(35, 'Las Vegas', 'Nevada'),
(36, 'Concord', 'New Hampshire'),
(37, 'Trenton', 'New Jersey'),
(38, 'Santa Fe', 'New Mexico'),
(39, 'Albany', 'New York'),
(40, 'Raleigh', 'North Carolina'),
(41, 'Bismarck', 'North Dakota'),
(42, 'Columbus', 'Ohio'),
(43, 'Oklahoma City', 'Oklahoma'),
(44, 'Salem', 'Oregon'),
(45, 'Harrisburg', 'Pennsylvania'),
(46, 'Providence', 'Rhode Island'),
(47, 'Columbia', 'South Carolina'),
(48, 'Pierre', 'South Dakota'),
(49, 'Nashville', 'Tennessee'),
(50, 'Chatanooga', 'Tennessee'),
(51, 'Knoxville', 'Tennessee'),
(52, 'Austin', 'Texas'),
(53, 'Dallas', 'Texas'),
(54, 'Houston', 'Texas'),
(55, 'Salt Lake City', 'Utah'),
(56, 'Montpelier', 'Vermont'),
(57, 'Richmond', 'Virginia'),
(58, 'Olympia', 'Washington'),
(59, 'Charleston', 'West Virginia'),
(60, 'Madison', 'Wisconsin'),
(61, 'Cheyenne', 'Wyoming'),
(62, 'Pago Pago', 'America Samoa'),
(63, 'Hagatna', 'Guam'),
(64, 'Saipan', 'Saipan'),
(65, 'San Juan', 'Puerto Rico'),
(66, 'Charlotte Amalie', 'U.S. Virgin Islands'),
(67, 'Washington ', 'DC'),
(68, 'Paris', 'France'),
(69, 'Tel Aviv', 'Israel'),
(70, 'Cairo', 'Egypt'),
(71, 'Rio de Janeiro', 'Brazil'),
(72, 'Philadelphia', 'Pennsylvania'),
(75, 'Chicago', 'Illinois'),
(76, 'Orlando', 'Florida'),
(77, 'New York', 'New York'),
(78, 'Montego Bay', 'Jamaica'),
(79, 'Paradise Island', 'Bahamas'),
(80, 'Punta Cana', 'Dominican Republic');

-- --------------------------------------------------------

--
-- Table structure for table `ep_payment_history`
--

DROP TABLE IF EXISTS `ep_payment_history`;
CREATE TABLE IF NOT EXISTS `ep_payment_history` (
  `ep_payment_history` int(11) NOT NULL AUTO_INCREMENT,
  `ep_invoice` varchar(50) NOT NULL,
  `ep_transaction` varchar(50) NOT NULL,
  `ep_pay_amount` varchar(50) NOT NULL,
  `ep_is_payment` char(1) NOT NULL,
  `ep_description` varchar(255) NOT NULL,
  `ep_video_category` int(11) NOT NULL,
  `ep_video_image` varchar(255) NOT NULL,
  `ep_file_upload` varchar(255) NOT NULL,
  `ep_created_time` varchar(19) NOT NULL,
  `ep_updated_time` varchar(19) NOT NULL,
  PRIMARY KEY (`ep_payment_history`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `ep_payment_history`
--

INSERT INTO `ep_payment_history` (`ep_payment_history`, `ep_invoice`, `ep_transaction`, `ep_pay_amount`, `ep_is_payment`, `ep_description`, `ep_video_category`, `ep_video_image`, `ep_file_upload`, `ep_created_time`, `ep_updated_time`) VALUES
(20, '1_7_56222868994298', '', '1', 'Y', '', 0, '', '', '2014-04-20 13:59:05', '2014-04-20 14:18:41'),
(21, '1_7_84581772651987', '', '1', 'N', '', 0, '', '', '2014-04-20 14:12:47', '2014-04-20 14:12:47'),
(22, '1_7_97493163533952', '', '1', 'N', '', 0, '', '', '2014-04-20 14:13:33', '2014-04-20 14:13:33'),
(23, '1_7_47366513578365', '', '1', 'N', '', 0, '', '', '2014-04-20 14:20:18', '2014-04-20 14:20:18'),
(24, '1_7_29956323736295', '', '1', 'Y', '', 0, '', '', '2014-04-20 14:23:33', '2014-04-20 14:24:00'),
(25, '1_7_79276362259341', '', '1', 'Y', '', 0, '', '', '2014-04-20 14:29:40', '2014-04-20 14:30:09'),
(26, '1_7_18387554726975', '', '1', 'Y', '', 0, '', '', '2014-04-20 14:32:18', '2014-04-20 14:32:43'),
(27, '1_7_93411787242957', '', '1', 'Y', '', 0, '', '', '2014-04-20 14:33:59', '2014-04-20 14:34:35'),
(28, '1_7_44436746524755', '', '1', 'Y', '', 0, '', '', '2014-04-20 14:36:06', '2014-04-20 14:36:32'),
(29, '3_7_56315758989311', '', '1', 'Y', '', 0, '', '', '2014-04-20 14:46:51', '2014-04-20 14:49:30'),
(30, '3_7_94867827818887', '', '1', 'Y', '', 0, '', '', '2014-04-20 14:59:55', '2014-04-20 15:00:25'),
(31, '1_11_44312516849326', '', '1', 'Y', '', 0, '', '', '2014-04-20 15:49:15', '2014-04-20 15:53:33'),
(32, '1_12_97731376899116', '', '1', 'N', '', 0, '', '', '2014-04-20 16:07:58', '2014-04-20 16:07:58'),
(33, '1_13_67582224678997', '', '1', 'N', '', 0, '', '', '2014-04-20 16:36:04', '2014-04-20 16:36:04'),
(34, '1_22_92459789477471', '', '1', 'N', '', 0, '', '', '2014-04-20 19:26:43', '2014-04-20 19:26:43'),
(35, '1_22_19618134693683', '', '1', 'N', '', 0, '', '', '2014-04-20 19:33:52', '2014-04-20 19:33:52'),
(36, '1_9_83655476425969', '', '1', 'N', '', 0, '', '', '2014-04-20 19:49:42', '2014-04-20 19:49:42'),
(37, '1_22_88666872286388', '', '1', 'N', '', 0, '', '', '2014-04-20 20:19:53', '2014-04-20 20:19:53'),
(38, '1_22_83869287584796', '', '1', 'N', '', 0, '', '', '2014-04-20 21:51:42', '2014-04-20 21:51:42'),
(39, '1_22_16132467618218', '', '1', 'Y', '', 0, '', '', '2014-04-20 21:57:53', '2014-04-20 22:03:42'),
(40, '3_22_26796448733148', '', '1', 'N', '', 0, '', '', '2014-04-21 13:46:10', '2014-04-21 13:46:10'),
(41, '1_23_88511591617245', '', '1', 'Y', '', 0, '', '', '2014-04-21 16:30:04', '2014-04-21 16:32:33'),
(42, '1_13_58869885546758', '', '1', 'N', '', 0, '', '', '2014-04-21 17:52:31', '2014-04-21 17:52:31'),
(43, '6_22_48743946859968', '', '1', 'N', '', 0, '', '', '2014-04-21 18:50:05', '2014-04-21 18:50:05'),
(44, '6_22_17968747413891', '', '1', 'Y', '', 0, '', '', '2014-04-21 19:15:44', '2014-04-21 19:18:35'),
(45, '3_22_15165734481819', '', '1', 'N', '', 0, '', '', '2014-04-21 19:23:01', '2014-04-21 19:23:01'),
(46, '1_25_14854769111836', '', '1', 'N', '', 0, '', '', '2014-04-21 19:44:26', '2014-04-21 19:44:26'),
(47, '4_22_34574873297582', '', '1', 'N', '', 0, '', '', '2014-04-24 08:30:23', '2014-04-24 08:30:23'),
(48, '4_22_36819235998246', '', '1', 'N', '', 0, '', '', '2014-04-24 11:07:30', '2014-04-24 11:07:30'),
(49, '4_22_47218151844638', '', '1', 'Y', '', 0, '', '', '2014-04-24 17:00:19', '2014-04-24 17:01:25'),
(50, '3_22_41551222462423', '', '1', 'N', '', 0, '', '', '2014-04-26 19:18:11', '2014-04-26 19:18:11'),
(51, '3_22_42229251236862', '', '99', 'N', '', 0, '', '', '2014-04-28 18:17:19', '2014-04-28 18:17:19'),
(52, '3_22_67171731346468', '', '99', 'N', '', 0, '', '', '2014-05-01 17:51:31', '2014-05-01 17:51:31'),
(53, '1_28_35863171896496', '', '99', 'N', '', 0, '', '', '2014-10-28 13:17:58', '2014-10-28 13:17:58'),
(54, '1_29_14681457691518', '', '99', 'N', '', 0, '', '', '2014-12-11 15:05:51', '2014-12-11 15:05:51'),
(55, '1_29_14681457691518', '', '99', 'N', '', 0, '', '', '2014-12-11 15:05:55', '2014-12-11 15:05:55'),
(56, '1_29_21222368773558', '', '99', 'N', '', 0, '', '', '2014-12-11 15:43:55', '2014-12-11 15:43:55'),
(57, '1_2_29_17483822662696', '', '99', 'N', '', 0, '', '', '2014-12-17 11:45:57', '2014-12-17 11:45:57'),
(58, '6_1_2_29_17483822662696', '', '99', 'N', '', 0, '', '', '2014-12-17 11:46:17', '2014-12-17 11:46:17');

-- --------------------------------------------------------

--
-- Table structure for table `ep_user`
--

DROP TABLE IF EXISTS `ep_user`;
CREATE TABLE IF NOT EXISTS `ep_user` (
  `ep_user` int(11) NOT NULL AUTO_INCREMENT,
  `ep_username` varchar(64) NOT NULL,
  `ep_password` varchar(128) NOT NULL,
  `ep_email` varchar(128) NOT NULL,
  `ep_referred_by` varchar(100) DEFAULT NULL,
  `ep_phone_number` varchar(64) DEFAULT NULL,
  `ep_city` varchar(128) NOT NULL,
  `ep_is_admin` char(1) NOT NULL DEFAULT 'N',
  `ep_business_last_payday` varchar(19) DEFAULT NULL,
  `ep_entertainment_last_payday` varchar(19) DEFAULT NULL,
  `ep_tourist_last_payday` varchar(19) DEFAULT NULL,
  `ep_investment_last_payday` varchar(19) DEFAULT NULL,
  `ep_is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `ep_created_time` varchar(19) NOT NULL,
  `ep_updated_time` varchar(19) NOT NULL,
  PRIMARY KEY (`ep_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `ep_user`
--

INSERT INTO `ep_user` (`ep_user`, `ep_username`, `ep_password`, `ep_email`, `ep_referred_by`, `ep_phone_number`, `ep_city`, `ep_is_admin`, `ep_business_last_payday`, `ep_entertainment_last_payday`, `ep_tourist_last_payday`, `ep_investment_last_payday`, `ep_is_locked`, `ep_created_time`, `ep_updated_time`) VALUES
(7, 'admin', 'ee6d6a999212a98a1300b1582a219ce9', 'jenistar90@gmail.com', 'cambodia', 'asia', 'Atlanta', 'Y', '2014-04-20 14:36:32', '2014-04-20 15:00:25', '', '', 0, '2014-04-05 14:36:14', '2014-04-20 15:03:42'),
(11, 'dionallen2009', 'ee6d6a999212a98a1300b1582a219ce9', 'dionallen2009@gmail.com', '2342342', '13234', '', 'N', '2014-04-20 15:53:33', NULL, NULL, NULL, 0, '2014-04-20 15:15:37', '2014-04-25 08:29:04'),
(12, 'dallen', 'ee6d6a999212a98a1300b1582a219ce9', 'dallen@desmear.com', '-1', '-1', 'Atlanta', 'N', NULL, NULL, NULL, NULL, 0, '2014-04-20 16:06:36', '2014-04-20 16:06:36'),
(13, 'KarenHaughton', '27435814a678a7085726db56db0cd0fe', 'karenhaughton@bellsouth.net', '-1', '-12312213', '', 'N', NULL, NULL, NULL, NULL, 0, '2014-04-20 16:34:14', '2014-04-25 08:28:26'),
(18, 'test123', '202cb962ac59075b964b07152d234b70', 'test123@gmail.com', '', '', 'testcit', 'N', NULL, NULL, NULL, NULL, 0, '2014-04-20 17:25:57', '2014-04-20 17:25:57'),
(22, 'dion', 'ee6d6a999212a98a1300b1582a219ce9', 'dionallen2006@gmail.com', '', '', 'Atlanta', 'N', '2014-04-20 22:03:42', NULL, '2014-04-24 17:01:25', '2014-04-21 19:18:35', 0, '2014-04-20 19:25:55', '2014-04-20 19:25:55'),
(23, 'test1', 'ee6d6a999212a98a1300b1582a219ce9', 'test1@yahoo.com', 'Dion Allen', '4048522090', 'Atlanta', 'N', '2014-04-21 16:32:33', NULL, NULL, NULL, 0, '2014-04-21 16:29:16', '2014-04-21 16:29:16'),
(24, 'Noid', 'ee6d6a999212a98a1300b1582a219ce9', 'Noid@yahoo.com', 'Dion', '5555555555', 'Atlanta', 'N', NULL, NULL, NULL, NULL, 0, '2014-04-21 19:42:21', '2014-04-21 19:42:21'),
(25, 'Lewis', 'ee6d6a999212a98a1300b1582a219ce9', 'Lewis@yahoo.com', 'Dion', '5555555555', 'Atlanta', 'N', NULL, NULL, NULL, NULL, 0, '2014-04-21 19:43:52', '2014-04-21 19:43:52'),
(26, 'test5', '202cb962ac59075b964b07152d234b70', 'test5@gmail.com', '123123', '32141234', '-1', 'N', NULL, NULL, NULL, NULL, 0, '2014-04-28 11:56:33', '2014-04-28 11:56:33'),
(27, 'test11', '21232f297a57a5a743894a0e4a801fc3', 'test11@gmail.com', '12312', '1231', '-1', 'N', NULL, NULL, NULL, NULL, 0, '2014-09-16 20:02:39', '2014-09-16 20:02:39'),
(28, 'solutionbuilt', 'dfcafc1d77a36aa845c978dc960f9d2b', 'matt@solutionbuilt.com', 'Dion', '4048357730', '-1', 'N', NULL, NULL, NULL, NULL, 0, '2014-10-28 13:16:42', '2014-10-28 13:16:42'),
(29, 'Alex', '534b44a19bf18d20b71ecc4eb77c572f', 'alex@solutionbuilt.com', 'dion', '4048357730', '-1', 'N', NULL, NULL, NULL, NULL, 0, '2014-12-11 14:06:13', '2014-12-11 14:06:13'),
(30, 'test', '05a671c66aefea124cc08b76ea6d30bb', 'test@mail.com', 'test2', '2312312', '-1', 'N', NULL, NULL, NULL, NULL, 0, '2014-12-28 11:21:05', '2014-12-28 11:21:05');

-- --------------------------------------------------------

--
-- Table structure for table `ep_video`
--

DROP TABLE IF EXISTS `ep_video`;
CREATE TABLE IF NOT EXISTS `ep_video` (
  `ep_video` int(11) NOT NULL AUTO_INCREMENT,
  `ep_user` int(11) NOT NULL,
  `ep_category` int(11) NOT NULL,
  `ep_description` varchar(512) NOT NULL,
  `ep_video_url` varchar(256) NOT NULL,
  `ep_video_thumb_small` varchar(256) NOT NULL,
  `ep_video_thumb_large` varchar(256) NOT NULL COMMENT '	',
  `ep_created_time` varchar(19) NOT NULL,
  `ep_updated_time` varchar(19) NOT NULL,
  `ep_view_count` int(11) NOT NULL DEFAULT '0',
  `ep_city` int(11) NOT NULL,
  PRIMARY KEY (`ep_video`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=201 ;

--
-- Dumping data for table `ep_video`
--

INSERT INTO `ep_video` (`ep_video`, `ep_user`, `ep_category`, `ep_description`, `ep_video_url`, `ep_video_thumb_small`, `ep_video_thumb_large`, `ep_created_time`, `ep_updated_time`, `ep_view_count`, `ep_city`) VALUES
(51, 7, 6, 'Microsoft ', 'video/948848_1396913712Microsoft 2014 Super Bowl Commercial_ Empowering-1.mp4', '', '/img/thumbnail/835662_1396913363.jpg', '2014-04-07 16:35:17', '2014-04-25 08:49:15', 10, 15),
(59, 7, 4, 'Atlanta zoo', 'video/799913_1396923038Zoo Atlanta TV Commercial- Letting Kids Discover the Zoo (BB.mp4', '', '/img/thumbnail/377637_1396922793.jpg', '2014-04-07 19:11:22', '2014-04-07 19:11:22', 6, 15),
(62, 7, 6, 'GE', 'video/224412_1396974550Fly into the Future (GE TV Commercial).mp4', '', '/img/thumbnail/863946_1396974518.jpg', '2014-04-08 09:29:14', '2014-04-08 09:29:14', 4, 15),
(63, 7, 6, 'visa', 'video/752373_1396974672Visa Olympics Commercial Sarah Hendrickson _Flying_.mp4', '', '/img/thumbnail/948885_1396974658.jpg', '2014-04-08 09:31:12', '2014-04-25 08:30:00', 1, 15),
(64, 7, 6, 'AT&T', 'video/211922_1396974824AT_T TV Commercial 2014 Network Guys Office _ AATV.mp4', '', '/img/thumbnail/266551_1396974812.jpg', '2014-04-08 09:33:44', '2014-04-08 09:33:44', 3, 15),
(65, 7, 6, 'Bank of America', 'video/135716_1396974974Bank of America TV Commercial, _Responsibility_ _ FunnyAds.mp4', '', '/img/thumbnail/133166_1396974961.jpg', '2014-04-08 09:36:14', '2014-04-08 09:36:14', 2, 15),
(71, 7, 1, 'Attorney', 'video/886727_1397314460Morgan _ Morgan - For The People.mp4', '', '/img/thumbnail/135984_1397314438.png', '2014-04-12 07:54:21', '2014-04-12 07:54:21', 4, 15),
(73, 7, 1, 'Windshield', 'video/135779_1397315810Safelite AutoGlass Windshield Repair Commercial.mp4', '', '/img/thumbnail/769138_1397315770.png', '2014-04-12 08:16:51', '2014-04-12 08:16:51', 3, 15),
(74, 7, 1, 'Surgeon', 'video/429745_1397315955Plastic Surgery Atlanta Georgia - John Connors MD.mp4', '', '/img/thumbnail/588231_1397315913.jpg', '2014-04-12 08:19:22', '2014-04-12 08:19:22', 3, 15),
(75, 7, 1, 'Accountant', 'video/836366_1397316942CPA Atlanta GA John D. Porter CPA, PC-1.mp4', '', '/img/thumbnail/965256_1397316920.jpg', '2014-04-12 08:35:43', '2014-04-12 08:35:43', 2, 15),
(76, 7, 1, 'Painter', 'video/249673_1397317411Georgia Painters 678 293 7223.mp4', '', '/img/thumbnail/436392_1397317376.jpg', '2014-04-12 08:43:34', '2014-04-12 08:43:34', 1, 15),
(77, 7, 1, 'Plumber', 'video/397557_139731788424 Hour Emergency Plumber Atlanta Ga_Atlanta Plumbers (404) .mp4', '', '/img/thumbnail/912156_1397317814.jpg', '2014-04-12 08:51:31', '2014-04-12 08:51:31', 2, 15),
(78, 7, 1, 'Mechanic', 'video/695759_1397318503Mobile Mechanic Atlanta GA _ Tel_ (404) 800-7122.mp4', '', '/img/thumbnail/336594_1397318471.jpg', '2014-04-12 09:01:44', '2014-04-12 09:01:44', 7, 15),
(79, 7, 1, 'Contractor', 'video/433396_1397319062Best Home Improvement Contractor _ Atlanta, GA (877) 605-542.mp4', '', '/img/thumbnail/241568_1397318956.jpg', '2014-04-12 09:11:11', '2014-04-12 09:11:11', 2, 15),
(80, 7, 1, 'Cardealer', 'video/219875_1397319447Brandt Auto Brokers Atlanta Used Cars in Marietta Georgia 30.mp4', '', '/img/thumbnail/626825_1397319405.jpg', '2014-04-12 09:17:28', '2014-04-12 09:17:28', 0, 15),
(81, 7, 1, 'Aquarium', 'video/966913_1397319702Georgia Aquarium Show Biz Fever Commercial.mp4', '', '/img/thumbnail/186153_1397319679.jpg', '2014-04-12 09:21:44', '2014-04-12 09:21:44', 1, 15),
(82, 7, 4, 'aquarium', 'video/647338_1397319844Georgia Aquarium Show Biz Fever Commercial.mp4', '', '/img/thumbnail/756185_1397319809.jpg', '2014-04-12 09:24:06', '2014-04-12 09:24:06', 5, 15),
(83, 7, 1, 'Bailbond', 'video/879269_1397320195Bail Bonds Jonesboro.mp4', '', '/img/thumbnail/976692_1397320175.jpg', '2014-04-12 09:29:56', '2014-04-12 09:29:56', 0, 15),
(84, 7, 1, 'Towing', 'video/771194_1397323470Tow Truck Service Atlanta 404-586-4433.mp4', '', '/img/thumbnail/485338_1397323445.jpg', '2014-04-12 10:24:33', '2014-04-12 10:24:33', 2, 15),
(85, 7, 1, 'Electrician', 'video/992332_1397323808mr dees commercial.mp4', '', '/img/thumbnail/189788_1397323685.jpg', '2014-04-12 10:30:20', '2014-04-12 10:30:20', 28, 15),
(86, 7, 1, 'Maid', 'video/584522_1397324134House Cleaning Services Atlanta Ga._ Maid Service Atlanta _ .mp4', '', '/img/thumbnail/688966_1397324117.jpg', '2014-04-12 10:35:35', '2014-04-12 10:35:35', 1, 15),
(87, 7, 1, 'Lawn', 'video/954179_1397325212Lawn Care Service, Hedge Trimming in Atlanta GA 30349.mp4', '', '/img/thumbnail/936875_1397325176.jpg', '2014-04-12 10:53:33', '2014-04-12 10:53:33', 5, 15),
(89, 7, 1, 'Ken Nugent personal injury car wreck attorney', 'video/814952_1397334693Neck Injury Lawyers in Atlanta GA _ (404) 885-1983.mp4', '', '/img/thumbnail/668379_1397334649.jpg', '2014-04-12 13:31:36', '2014-04-12 13:31:36', 1, 15),
(90, 7, 1, 'Bail Bonding ', 'video/549337_1397334871Bail Bonds in Atlanta GA Hosea WIlliams Bonding Company.mp4', '', '/img/thumbnail/679956_1397334853.jpg', '2014-04-12 13:34:32', '2014-04-12 13:34:32', 1, 15),
(91, 7, 1, 'Criminal defense attorney', 'video/149149_1397335673Atlanta criminal lawyer - What Should I Do if Arrested Atlan.mp4', '', '/img/thumbnail/121784_1397335648.jpg', '2014-04-12 13:47:57', '2014-04-12 13:47:57', 1, 15),
(92, 7, 1, 'Website develpment', 'video/189167_1397336119Website Design Atlanta_ 888-281--5450_Website design and dev.mp4', '', '/img/thumbnail/113546_1397336055.jpg', '2014-04-12 13:55:27', '2014-04-12 13:55:27', 2, 15),
(94, 7, 1, 'Arthur Murray dance lessons', 'video/786142_1397337461Dance Studio Atlanta GA Arthur Murray Dance Studio.mp4', '', '/img/thumbnail/855512_1397337441.jpg', '2014-04-12 14:17:42', '2014-04-12 14:17:42', 1, 15),
(95, 7, 1, 'DUI defense attorney', 'video/223862_1397348416Michael M. Hawkins Atlanta GA, DUI Lawyer.mp4', '', '/img/thumbnail/338199_1397348369.png', '2014-04-12 17:20:22', '2014-04-12 17:20:22', 1, 15),
(96, 7, 1, 'Cheetah strip club', 'video/393193_1397348887Cheetah Lounge Atlanta, Ga.mp4', '', '/img/thumbnail/247371_1397348840.jpg', '2014-04-12 17:28:12', '2014-04-12 17:28:12', 3, 15),
(97, 7, 1, 'Babes strip club', 'video/531625_1397349191Club Babes Strip Club Open Mic Every Tuesday artist win $150.mp4', '', '/img/thumbnail/124319_1397349050.png', '2014-04-12 17:33:12', '2014-04-12 17:33:12', 2, 15),
(98, 7, 1, 'Strokers strip club', 'video/633853_1397349415Strokers Strip Club Commercial 05-1.mp4', '', '/img/thumbnail/514456_1397349387.gif', '2014-04-12 17:36:58', '2014-04-12 17:36:58', 4, 15),
(99, 7, 4, 'Six Flags ', 'video/298992_1397350543Hurricane Harbor New for 2014 at Six Flags Over Georgia New .mp4', '', '/img/thumbnail/765347_1397350483.jpg', '2014-04-12 17:55:50', '2014-04-12 17:55:50', 11, 15),
(100, 7, 4, 'World of Coca Cola', 'video/298572_1397350681World of Coca-Cola _15 Video Commercial.mp4', '', '/img/thumbnail/348311_1397350667.jpg', '2014-04-12 17:58:03', '2014-04-12 17:58:03', 1, 15),
(101, 7, 4, 'Stone Mountain Park', 'video/398115_1397351070Stone Mountain commercial.mp4', '', '/img/thumbnail/519716_1397350940.jpg', '2014-04-12 18:04:34', '2014-04-12 18:04:34', 2, 15),
(102, 7, 4, 'Fernbank museum', 'video/945828_1397351443Fernbank Museum Martinis _ IMAX TV spot (fall 2011).mp4', '', '/img/thumbnail/137494_1397351388.jpg', '2014-04-12 18:10:50', '2014-04-12 18:10:50', 2, 15),
(103, 7, 3, 'Benihana Japanese restaurant', 'video/158749_1397351812Walter Hopewell Benihana Commercial 001.wmv.mp4', '', '/img/thumbnail/153684_1397351774.jpg', '2014-04-12 18:16:53', '2014-04-12 18:16:53', 3, 15),
(104, 7, 5, 'Lalecha Green actress', 'video/647593_1397352336La_Lecha Green as _BAM_.mp4', '', '/img/thumbnail/346238_1397352295.jpg', '2014-04-12 18:25:41', '2014-04-12 18:25:41', 4, 15),
(105, 7, 2, 'Jobseeker marketing manager', 'video/889479_1397353784Seeking Employment Commercial for James Peters.mp4', '', '/img/thumbnail/652672_1397353405.jpg', '2014-04-12 18:49:46', '2014-04-12 18:49:46', 5, 15),
(106, 7, 4, 'Centennial Olympic Park', 'video/313978_1397398028What a wonderful world - Centennial Olympic Park.mp4', '', '/img/thumbnail/377379_1397397752.jpg', '2014-04-13 07:07:40', '2014-04-13 07:07:40', 1, 15),
(107, 7, 4, 'Atlanta Botanical Gardens', 'video/412152_1397398388Atlanta Botanical Garden Commercial.mp4', '', '/img/thumbnail/812778_1397398227.jpg', '2014-04-13 07:13:21', '2014-04-13 07:13:21', 2, 15),
(108, 7, 1, 'Koru Massage ', 'video/861532_1397398959Koru Massage Massage Therapy in Atlanta, GA.mp4', '', '/img/thumbnail/226596_1397398933.jpg', '2014-04-13 07:22:40', '2014-04-13 07:22:40', 1, 15),
(109, 7, 1, 'Physical Therapist', 'video/156323_1397400495Physical Therapy Atlanta GA Dunwoody Physical Therapists Atl.mp4', '', '/img/thumbnail/536655_1397399683.png', '2014-04-13 07:48:24', '2014-04-13 07:48:24', 0, 15),
(110, 7, 1, 'Chiropractor', 'video/515313_1397401198Dr. STEVEN WILDER, CHIROPRACTOR - Conyers, Georgia - 30 Sec..mp4', '', '/img/thumbnail/794175_1397401163.jpg', '2014-04-13 07:59:59', '2014-04-13 07:59:59', 0, 15),
(111, 7, 5, 'Playwrite TY Martin', 'video/143825_1397427893PLAYWRIGHT T.Y. MARTIN.mp4', '', '/img/thumbnail/997211_1397427709.jpg', '2014-04-13 15:25:11', '2014-04-13 15:25:11', 11, 15),
(112, 7, 1, 'Doctor Pediatrician', 'video/732461_1397437316KidsTime Pediatrics AfterHours Comercial 2011.mov.mp4', '', '/img/thumbnail/644266_1397437223.gif', '2014-04-13 18:01:59', '2014-04-13 18:01:59', 1, 15),
(113, 7, 1, 'Used tires', 'video/455171_1397437539USED TIRES ATLANTA,404 932 1485,www.usedtiresatlanta.com,GOO.mp4', '', '/img/thumbnail/827411_1397437510.jpg', '2014-04-13 18:05:41', '2014-04-13 18:05:41', 0, 15),
(114, 7, 1, 'Liposuction', 'video/847194_1397438956Liposuction Atlanta GA Plastic Surgeon.mp4', '', '/img/thumbnail/732181_1397438919.jpg', '2014-04-13 18:29:21', '2014-04-13 18:29:21', 0, 15),
(115, 7, 6, 'Sirius', 'video/526324_13975251292009 Sirius XM commercial.mp4', '', '/img/thumbnail/978382_1397525096.gif', '2014-04-14 18:25:32', '2014-04-14 18:25:32', 8, 15),
(116, 7, 6, 'Sea World', 'video/812373_1397525599Sea World Touch A World Commercial-2.mp4', '', '/img/thumbnail/791597_1397525540.jpg', '2014-04-14 18:33:23', '2014-04-14 18:33:23', 1, 15),
(117, 7, 6, 'Apple ', 'video/392539_1397526499Apple - iPhone 5 - TV Ad - Photos Every Day.mp4', '', '/img/thumbnail/489777_1397526443.jpg', '2014-04-14 18:48:25', '2014-04-14 18:48:25', 1, 15),
(118, 7, 6, 'Wells Fargo', 'video/244814_1397529692Wells Fargo Commercial_ 6 String Dream.mp4', '', '/img/thumbnail/974939_1397529660.jpg', '2014-04-14 19:41:36', '2014-04-14 19:41:36', 0, 15),
(119, 7, 3, 'Velvet room night club', 'video/587521_13975325772009. 05. 16 Crown J Live @ Velvet Room ATL.mp4', '', '/img/thumbnail/383766_1397532541.png', '2014-04-14 20:29:42', '2014-04-14 20:29:42', 15, 15),
(120, 7, 4, 'Disney World', 'video/844978_1397602132Disney World Commercial - _My Vacation_.mp4', '', '/img/thumbnail/179774_1397602038.jpg', '2014-04-15 15:48:55', '2014-04-15 15:48:55', 2, 15),
(121, 7, 4, 'Disneyland', 'video/922415_13976022422014 Disneyland Resort California Holiday Trailer TV Advert .mp4', '', '/img/thumbnail/165223_1397602180.jpg', '2014-04-15 15:50:52', '2014-04-15 15:50:52', 1, 15),
(122, 7, 1, 'Extreme beauty hair salon ', 'video/693391_1397609517Extreem Beauty Hair Salon (commercial created by AFA).mp4', '', '/img/thumbnail/141247_1397609487.jpg', '2014-04-15 17:51:59', '2014-04-15 17:51:59', 3, 15),
(123, 7, 1, 'Aqua force pressure washing', 'video/675831_1397610027Pressure Washing and Roof Cleaning in Atlanta Georgia.mp4', '', '/img/thumbnail/391523_1397609974.gif', '2014-04-15 18:00:28', '2014-04-15 18:00:28', 0, 15),
(124, 7, 1, 'Home depot hardware store', 'video/689794_1397610846The Home Depot The Bath You Want TV Commercial Super Bowl 20.mp4', '', '/img/thumbnail/117161_1397610829.jpg', '2014-04-15 18:14:07', '2014-04-15 18:14:07', 2, 15),
(125, 7, 1, 'Emergency Electrician', 'video/393236_1397611310Electrical Contractors Atlanta GA (678) 369-4832_ Best Price.mp4', '', '/img/thumbnail/864249_1397611274.png', '2014-04-15 18:21:54', '2014-04-15 18:21:54', 1, 15),
(126, 7, 1, 'Thrasher contracting utility\n', 'video/462865_1397611749Thrasher Contracting LLC - Atlanta, GA.mp4', '', '/img/thumbnail/338529_1397611705.png', '2014-04-15 18:29:14', '2014-04-15 18:29:14', 2, 15),
(127, 7, 1, 'Roofing contractor roofer', 'video/865881_1397612105Atlanta Commercial Roofing Company - 404-369-1122 - Commerci.mp4', '', '/img/thumbnail/382384_1397612061.jpg', '2014-04-15 18:35:10', '2014-04-15 18:35:10', 0, 15),
(128, 7, 1, 'Used cars Atlanta', 'video/815267_1397612462Used Cars Atlanta Ga (404) 369-0703.mp4', '', '/img/thumbnail/578985_1397612434.jpg', '2014-04-15 18:41:03', '2014-04-15 18:41:03', 0, 15),
(129, 7, 1, 'Montlick and Associates Auto Injury ', 'video/785578_1397616001Atlanta Accident Attorney, MONTLICK _ ASSOCIATES. Experience.mp4', '', '/img/thumbnail/143475_1397615978.jpg', '2014-04-15 19:40:05', '2014-04-15 19:40:05', 1, 15),
(130, 7, 1, 'Baxter and Nesmith bankruptcy  lawyer', 'video/581525_1397616511Bankruptcy Attorney Atlanta _ Bankruptcy Lawyers in Atlanta .mp4', '', '/img/thumbnail/984535_1397616443.jpg', '2014-04-15 19:48:38', '2014-04-15 19:48:38', 1, 15),
(131, 7, 1, 'King and King Bankruptcy Attorney', 'video/384362_1397616914Atlanta Bankruptcy Attorney _ Atlanta Bankruptcy Lawyer 404--1.mp4', '', '/img/thumbnail/296737_1397616900.jpg', '2014-04-15 19:55:15', '2014-04-15 19:55:15', 3, 15),
(137, 9, 1, 'jenitest1', 'video/149984_1397748356.mp4', '', '/img/thumbnail/227234_1397748265.png', '2014-04-17 08:26:09', '2014-04-17 08:26:09', 0, 15),
(138, 9, 3, 'jenitest', 'video/469987_1397748810.mp4', '', '/img/thumbnail/933645_1397748800.png', '2014-04-17 08:33:31', '2014-04-17 08:33:31', 1, 15),
(146, 11, 1, 'Pest Control Exterminator', 'video/625529_1398034635.mp4', '', '/img/thumbnail/111994_1398034617.gif', '2014-04-20 15:57:18', '2014-04-20 15:57:18', 0, 15),
(149, 7, 1, 'Ruth Chris Steak House restaurant', 'video/324339_1398396989.mp4', '', '/img/thumbnail/767339_1398396963.jpg', '2014-04-24 20:36:33', '2014-04-24 20:36:33', 3, 15),
(150, 7, 3, 'Ruth Chris Steak House restaurant', 'video/798982_1398397098.mp4', '', '/img/thumbnail/888236_1398397083.jpg', '2014-04-24 20:38:20', '2014-04-24 20:38:20', 3, 15),
(155, 22, 1, 'Cambodian Hair Weave Virgin Indian Extensions', 'video/111594_1398610776.mp4', '', '/img/thumbnail/334948_1398610755.png', '2014-04-27 07:59:44', '2014-04-27 07:59:44', 17, 15),
(156, 7, 3, 'IP Casino', 'video/541531_1398659720.mp4', '', '/img/thumbnail/649691_1398659676.jpg', '2014-04-27 21:35:24', '2014-04-27 21:35:24', 3, 32),
(157, 7, 3, 'Medieval Times Restaraunt Entertainment', 'video/868864_1398686647.mp4', '', '/img/thumbnail/912523_1398686602.jpg', '2014-04-28 05:04:10', '2014-04-28 05:04:10', 2, 15),
(158, 7, 3, 'Rays in the city restaurant', 'video/767523_1398687771.mp4', '', '/img/thumbnail/316897_1398687732.jpg', '2014-04-28 05:22:54', '2014-04-28 05:22:54', 1, 15),
(159, 7, 3, 'Grand Casino', 'video/755341_1398711064.mp4', '', '/img/thumbnail/615775_1398711038.jpg', '2014-04-28 11:51:07', '2014-04-28 11:51:07', 5, 32),
(160, 7, 1, 'Cambodian Hair Virgin Hair Extensions', 'video/532722_1398721940.mp4', '', '/img/thumbnail/939843_1398721808.png', '2014-04-28 14:52:36', '2014-04-28 14:52:36', 0, 0),
(161, 7, 5, 'Model', 'video/136922_1399146534.mp4', '', '/img/thumbnail/759825_1399146489.jpg', '2014-05-03 12:48:59', '2014-05-03 12:48:59', 0, 0),
(162, 7, 1, 'Element Model Management Modelling Model Agency', 'video/192342_1399146705.mp4', '', '/img/thumbnail/176513_1399146651.png', '2014-05-03 12:51:51', '2014-05-03 12:51:51', 0, 0),
(163, 7, 5, 'Model', 'video/426512_1399147176.mp4', '', '/img/thumbnail/387473_1399147133.jpg', '2014-05-03 12:59:40', '2014-05-03 12:59:40', 0, 0),
(164, 7, 5, 'Whitney L model Atlanta Georgia', 'video/644972_1399147461.mp4', '', '/img/thumbnail/812513_1399147415.jpg', '2014-05-03 13:04:26', '2014-05-03 13:04:26', 0, 0),
(165, 7, 2, 'Administrative Assistant', 'video/948386_1399147737.mp4', '', '/img/thumbnail/276724_1399147731.jpg', '2014-05-03 13:08:59', '2014-05-03 13:08:59', 0, 0),
(166, 22, 5, 'Model', 'video/866387_1399148820.mp4', '', '/img/thumbnail/723296_1399148770.jpg', '2014-05-03 13:27:07', '2014-05-03 13:27:07', 0, 0),
(167, 22, 5, 'Model', 'video/871847_1399150250.mp4', '', '/img/thumbnail/217986_1399150205.jpg', '2014-05-03 13:50:56', '2014-05-03 13:50:56', 0, 0),
(168, 22, 5, 'Model', 'video/444893_1399159806.mp4', '', '/img/thumbnail/162583_1399159752.jpg', '2014-05-03 16:30:12', '2014-05-03 16:30:12', 0, 0),
(169, 7, 4, 'testjeni1', 'video/156768_1399184703.mp4', '', '/img/thumbnail/458242_1399184681.jpg', '2014-05-03 23:25:03', '2014-05-03 23:25:03', 0, 0),
(170, 7, 4, 'testjeni1', 'video/471363_1399184972.mp4', '', '/img/thumbnail/363789_1399184950.png', '2014-05-03 23:29:32', '2014-05-03 23:29:32', 0, 0),
(171, 7, 2, 'test123', 'video/681582_1399185351.mp4', '', '/img/thumbnail/242451_1399185339.png', '2014-05-03 23:35:51', '2014-05-03 23:35:51', 0, 0),
(173, 22, 5, 'Model', 'video/893439_1399214006.mp4', '', '/img/thumbnail/656557_1399213943.jpg', '2014-05-04 07:33:33', '2014-05-04 07:33:33', 3, 15),
(174, 22, 5, 'Model Atlanta Georgia', 'video/281314_1399215546.mp4', '', '/img/thumbnail/127837_1399215512.jpg', '2014-05-04 07:59:11', '2014-05-04 07:59:11', 0, 15),
(175, 22, 5, 'Desiray Model Atlanta Georgia', 'video/387768_1399216172.mp4', '', '/img/thumbnail/869863_1399216133.jpg', '2014-05-04 08:09:39', '2014-05-04 08:09:39', 3, 15),
(176, 22, 5, 'Alex model mode management', 'video/333664_1399257358.mp4', '', '/img/thumbnail/568741_1399257297.png', '2014-05-04 19:36:06', '2014-05-04 19:36:06', 1, 15),
(177, 22, 1, 'Model agency', 'video/968166_1399258234.mp4', '', '/img/thumbnail/262383_1399258186.png', '2014-05-04 19:50:38', '2014-05-04 19:50:38', 0, 15),
(178, 22, 4, 'Statue of Liberty', 'video/199633_1399519898.mp4', '', '/img/thumbnail/721947_1399519796.jpg', '2014-05-07 20:31:49', '2014-05-07 20:31:49', 0, 39),
(180, 22, 4, 'Washington monument', 'video/468529_1399520644.mp4', '', '/img/thumbnail/147849_1399520606.jpg', '2014-05-07 20:44:06', '2014-05-07 20:44:06', 0, 67),
(181, 22, 4, 'Bahamas Beach resort', 'video/739979_1399601896.mp4', '', '/img/thumbnail/873452_1399601825.jpg', '2014-05-08 19:18:23', '2014-05-08 19:18:23', 3, 79),
(182, 22, 5, 'Football player receiver', 'video/667122_1399602475.mp4', '', '/img/thumbnail/247188_1399602417.jpg', '2014-05-08 19:28:04', '2014-05-08 19:28:04', 3, 54),
(183, 7, 3, 'night club Atlanta dance club', 'video/567394_1410906387.mp4', '', '/img/thumbnail/396148_1410906338.png', '2014-09-16 16:26:29', '2014-09-16 16:26:29', 23, 15),
(198, 7, 1, 'Network Security Consulting IT', 'video/831455_1411680828.mp4', '', '/img/thumbnail/784548_1411680766.jpg', '2014-09-25 15:33:49', '2014-09-25 15:33:49', 0, 15),
(199, 7, 1, 'Earth Promo Marketing Advertising', 'video/963797_1411784051.mp4', '', '/img/thumbnail/174429_1411784014.jpg', '2014-09-26 20:14:12', '2014-09-26 20:14:12', 5, 15),
(200, 29, 5, 'Professional Soccer Coach', 'video/249937_1418841808.mp4', '', '/img/thumbnail/564115_1418841798.png', '2014-12-17 11:43:28', '2014-12-17 11:43:28', 0, 15);

-- --------------------------------------------------------

--
-- Table structure for table `ep_video_view_count`
--

DROP TABLE IF EXISTS `ep_video_view_count`;
CREATE TABLE IF NOT EXISTS `ep_video_view_count` (
  `ep_video_view_count` int(11) NOT NULL,
  `ep_video` int(11) NOT NULL,
  `ep_count` int(11) NOT NULL,
  `ep_created_time` varchar(19) NOT NULL,
  `ep_updated_time` varchar(19) NOT NULL,
  PRIMARY KEY (`ep_video_view_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
